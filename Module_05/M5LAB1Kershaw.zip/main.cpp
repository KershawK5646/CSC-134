// CSC-134
// M5LAB1
// Kyler Kershaw
// 06/27/20

#include <iostream>
#include <math.h>

using namespace std;

// exponential growth Function
int growth(int number){
  int answer;
  answer = pow((double)2, (double)number);
  return answer;
}

// squareFunction
int square(int number){
  int result = number * number;
  return result;
}

// printAnswer Function
void printAnswerExp(int number, int result){
  //cout << count << " : " << numSquared << endl;

  double salary = (double) result / 100;
  cout << "on day " << number + 1 << " you earn $" << salary << endl;
}

void printAnswer100(int number, int result){
  //cout << count << " : " << numSquared << endl;

  double salary = (double) result;
  cout << "on day " << number + 1 << " you earn $" << salary << endl;
}

// Calculate penny a day
void pennyADay(){
  int number, result;
    number = 0;
    cout << "if you start with a penny and double that every day:" << endl;
    while (number <= 30){
      result = growth(number);
      printAnswerExp(number, result);
      number++;
    }
}

void dollarADay(){
  cout << "If you get $100 added on every day you work, you'd have: " << endl;
  int dailyPay = 100;
  int dayCounter = 0;

  while (dayCounter < 30){
    dailyPay = dailyPay + (100 * dayCounter);
    printAnswer100(dayCounter, dailyPay);
    dayCounter++;
  }
}

// Main
int main() {
  pennyADay();
  dollarADay();
}
