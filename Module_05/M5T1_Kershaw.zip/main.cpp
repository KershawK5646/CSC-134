// CSC-134
// Kyler Kershaw
// M5T1
// 06/27/20


#include <iostream>
using namespace std;

// Declare our functions
string formatAnswer(int answer);
void printAnswer(string msg);

int main() {
  int answer = 5;
  string message;
  message = formatAnswer(answer);
  printAnswer(message);
  return 0;
}

// Define our functions
string formatAnswer(int answer){
  // Make a nice looking string containing the answer.
  string answerMessage;
  answerMessage = "The answer is ";
  answerMessage += to_string(answer);

  return answerMessage;
}
void printAnswer (string msg){
  // Display our message
  cout << msg << endl;
}