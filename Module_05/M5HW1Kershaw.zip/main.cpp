// CSC-134
// M5HW1
// Kyler Kershaw
// 06/28/20

#include <iostream>
#include <iomanip>
using namespace std;

void question1();
void question2();
void question3();
void question4();
void question5();
void goemetryMenu();
void mainMenu();
void areaOfCircle();
void areaOfRectangle();
void areaOfTriangle();
double getDouble();
int getInt();


int main() {
  // Variables
  int userSelection;
  bool goAgain = true;
  mainMenu();
  while(goAgain == true){
    userSelection = getInt();
    cout << fixed << setprecision(2);
    // input validation
    while (userSelection > 6){
      cout << "Invalid entry. Please enter a number between 1 and 6: " << endl;
      userSelection = getInt();
    }
    if (userSelection == 1){
      question1();
    }else if(userSelection ==2){
      question2();
    }else if(userSelection ==3){
      question3();
    }else if(userSelection == 4){
      question4();
      mainMenu();
    }else if(userSelection == 5){
      question5();
    }else{
      break;
    }
  }
}

// Question 1
void question1(){
  // Ask for 3 month names, rainfall for those months
  // calculate the avg for all rainfall and display

  // Variables
  string month1, month2, month3;
  double rainFall1, rainFall2, rainFall3;
  double totalRain = 0.0;
  double rainAvg;
  
  // Get month name and rain for each month.
  cout << "Enter the name of the first month: " << endl;
  cin >> month1;
  // Get rainfall for month 1.
  cout << "Enter in inches how much rain fell in " << month1 << endl;
  rainFall1 = getDouble();

  // Get month name and rain for each month.
  cout << "Enter the name of the second month: " << endl;
  cin >> month2;
  // Get rainfall for month 2.
  cout << "Enter in inches how much rain fell in " << month2 << endl;
  rainFall2 = getDouble();

  // Get month name and rain for each month.
  cout << "Enter the name of the third month: " << endl;
  cin >> month3;
  // Get rainfall for month 3.
  cout << "Enter in inches how much rain fell in " << month3 << endl;
  rainFall3 = getDouble();
  
  totalRain = rainFall1 + rainFall2 + rainFall3;
  rainAvg = totalRain / 3;

  cout << "The average rainfall for " << month1 << ", " << month2 << ", " << month3 << " is " << rainAvg << "inches!" << endl;

}

// Question 2
void question2(){
  // Get L/W/H of block, calculate volume, no 0 or neg values allowed.
  double length, width, height, volume;
  // Prompts
  cout << "What is the length: " << endl; 
  length = getDouble();
  cout << "What is the width: " << endl; 
  width = getDouble();
  cout << "What is the height: " << endl; 
  height = getDouble();
  // Calculate
  volume = length * width * height;
  cout << "Lenght: " << length;
  cout << "Width: " << width;
  cout << "Height: " << height;
  cout << "Total volume of this block is: " << volume;
}

// Quesiton 3
void question3(){
  // Enter number 1-10 and display Roman numerals of their entry.
  // Variables
  int userNumber;
  // Get number between 1 and 10
  cout << "Enter a number between 1 and 10: " << endl;
  userNumber = getInt();
  while (userNumber > 10){
    cout << "Invalid entry. Please enter a number between 1 and 10: " << endl;
    userNumber = getInt();
  }
  // Display romans of number
  cout << "Your number is: " << userNumber << endl;
  cout << "In Roman numerals, it looks like this: ";
  if (userNumber == 1){
    cout << "I";
  } else if(userNumber == 2){
    cout << "II";
  }else if(userNumber == 3){
    cout << "III";
  }else if(userNumber == 4){
    cout << "IV";
  }else if(userNumber == 5){
    cout << "V";
  }else if(userNumber == 6){
    cout << "VI";
  }else if(userNumber == 7){
    cout << "VII";
  }else if(userNumber == 8){
    cout << "VII";
  }else if(userNumber == 9){
    cout << "IX";
  }else{
    cout << "X";
  }
}

//Question 4
void question4(){
  // declare Variables
  int userSelection;
  goemetryMenu();
  userSelection = getInt();
  while (userSelection > 4){
    cout << "Invalid entry. Please enter a number between 1 and 4: " << endl;
    userSelection = getInt();
  }
  cout << "Selected: ";
  if(userSelection == 1){
    cout << "Area of a Circle: " << endl;
    areaOfCircle();
  }else if(userSelection == 2){
    cout << "Area of a Rectangle: " << endl;
    areaOfRectangle();
  }else if(userSelection == 3){
    cout << "Area of a Triangle: " << endl;
    areaOfTriangle();
  }else{
    cout << "Goodbye" << endl;
  }
}

// Question5
void question5(){
  int speed, time, distance;

  cout << "What is the speed of the vehicle in mph: " << endl;
  speed = getInt();
  cout << "How many hours has it traveled: " << endl;
  time = getInt();

  cout << "Hours : Distance Traveled \n=============================" << endl;
  for (int i=0; i <= time; ++i){
    distance = speed * i;
    cout << i << " : " << distance << endl;
  }
  
}

// Gets double from the user. CANNOT be = to or below 0.
double getDouble(){
  // Declare
  double enteredDouble;
  // Prompt and get
  cout << "Enter a number: " << endl;
  cin >> enteredDouble;
  while (enteredDouble <= 0){
      cout << "Can not be less than or equal to 0. \nPlease enter a valid number: " << endl;
      cin >> enteredDouble;
    }
  // Return
  return enteredDouble;
}
// Gets int from the user. CANNOT be = to or below 0.
int getInt(){
  int enteredInt;
  cout << "Enter a number with no decimal: " << endl;
  cin >> enteredInt;
  while (enteredInt <= 0){
    cout << "Can not be less than or equal to 0. \nPlease enter a valid number: " << endl;
    cin >> enteredInt;
  }
  return enteredInt;
}

// Display user options for quesiton 4.
void goemetryMenu(){
  cout << "Geometry Calculator" << endl;
  cout << "1. Calculate the Area of a Circle" << endl;
  cout << "2. Calculate the Area of a Rectangle" << endl;
  cout << "3. Calculate the Area of a Triangle" << endl;
  cout << "4. Quit" << endl;
}

// Calculate the area of a circle
void areaOfCircle(){
  // Variables
  double pi, radius, area;
  pi = 3.14159;

  // Get radius
  cout << "Enter the radius of your circle: ";
  radius = getDouble();

  area = pi * (radius * radius);
  cout << "The area of your circle with a radius of " << radius << " is: " << area << endl;
}

// Calculate the area of a rectangle
void areaOfRectangle(){
  // Variables
  double length, width, area;
  // Get dimensions
  cout << "Enter the length of your rectangle: " << endl;
  length = getDouble();
  cout << "Enter the width of your rectangle: " << endl;
  width = getDouble();
  // Calculate area and display
  area = length * width;
  cout << "The area of your rectangle with a lenght of " << length << " and a width of " << width << " is: " << area << endl;
}

// Calculate the area of a triangle
void areaOfTriangle(){
  // Variables
  double base, height, area;

  cout << "Enter the base of your triangle: " << endl;
  base = getDouble();
  cout << "Enter the height of your triangle: " << endl;
  height = getDouble();
  // Calculate area
  area = base * height * 0.5;
  cout << "The area of your triangle with a base of " << base << " and a height of " << height << " is: " << area;
}

// main menu
void mainMenu(){
  cout << "MAIN MENU: " << endl;
  cout << "1. Rainfall Tracker" << endl;
  cout << "2. Block Volume Calculator" << endl;
  cout << "3. Roman Numerals" << endl;
  cout << "4. Geometry Calculator" << endl;
  cout << "5. Distance Calculator" << endl;
  cout << "6. EXIT" << endl;
}