// CSC-134
// M5T2
// Kyler Kershaw
// 06/27/20

#include <iostream>
using namespace std;

// square function
int squareFunction(int number){
  int answer;
  answer = number * number;
  return answer;
}

// printAnswer Function
void printAnswer(int count, int numSquared){
  cout << count << " squared is: " << numSquared << endl;
}

// Main
int main() {
  int count = 1;
  int numSquared;
  int i;
  for (i=0; i<10; ++i){
    numSquared = squareFunction(count);
    printAnswer(count, numSquared);
    count++;
  }
}